# Secure iOS App with Face ID & Apple Pay

### Description
This system ensures security using Face ID, Apple Pay, and Quantum Encryption.

### Features:
- ✅ **Face ID & Apple Pay Authentication**
- ✅ **Quantum Encryption & Bitdefender Protection**
- ✅ **Secure API Transactions**
- ✅ **Restricted to Account: ervin210@icloud.com**
- ✅ **GitHub-Ready Code for Secure Upload**

### Installation Guide:
1. **Extract the ZIP file.**
2. **Open the `main.swift` file in Xcode.**
3. **Compile and run the app on your iPhone/iPad.**
4. **Ensure your Apple Pay and Face ID are enabled for authentication.**

### Licensing:
This software is protected under the **NDA Agreement** and **Copyright Law**.
Only authorized users are permitted to use this software.

### Owner:
**Ervin Remus Radosavlevici** (ervin210@icloud.com)
